import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myTestApp';
  Query="";
  tasks:Array<String>;
  donelist:Array<String>;
  constructor(){
    this.tasks=new Array<String>();
    this.donelist=new Array<String>();
  }

  addTask(){
    this.tasks.push(this.Query);
    console.log(this.tasks);
    this.Query="";
  }
  removeTask(item:String){
     this.tasks=this.tasks.filter(x=>x!=item);   
     this.donelist=this.donelist.filter(x=>x!=item);
  }
  isCompleted(item:String){
    let result=this.donelist.find(i=>i==item);
   return (result==item);
  }
  complete(item:String){
    this.donelist.push(item);
  }

}