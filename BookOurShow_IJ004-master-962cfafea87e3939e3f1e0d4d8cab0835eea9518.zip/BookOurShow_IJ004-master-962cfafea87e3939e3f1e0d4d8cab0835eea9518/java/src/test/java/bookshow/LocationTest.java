package bookshow;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.bookourshow.app.App;
import com.bookourshow.model.Address;
import com.bookourshow.model.City;
import com.bookourshow.model.Movie;
import com.bookourshow.model.MovieCategory;
import com.bookourshow.model.State;
import com.bookourshow.repo.AddressRepoService;
import com.bookourshow.repo.AddressRepository;

/*Spring Test
@RunWith(SpringRunner .class)*/
@RunWith(MockitoJUnitRunner.class)
/*@SpringBootTest(classes=App.class)*/
public class LocationTest {

	@Mock
	AddressRepository addressRepository;
	
	@InjectMocks
	AddressRepoService addressRepoService;
	/*@MockBean
	AddressRepository addressRepository;
	
	@Autowired(required=true)
	AddressRepoService addressRepoService;*/
	/*@Autowired(required=true)
	AddressRepoService addressRepoService;*/
	
	Address address;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("BEFORE CLASS TESTS STARTS");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("AFTER CLASS TESTS ENDS");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("BEFORE TEST STARTS");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("AFTER TESTS ENDS");
	}

	@Test
	public void testFetchedMovieDetails() {
		List<Address> expCity=new ArrayList<Address>();
		
		City city=new City(1,"KOCHI");
		State state=new State(1,"KERALA");
		Address address=new Address(1,city,state);
		expCity.add(address);
		
		city=new City(2,"ALAPPUZHA");
		state=new State(1,"KERALA");
		address=new Address(2,city,state);
		expCity.add(address);
		
		city=new City(3,"TUNI");
		state=new State(4,"ANDHRA PRADESH");
		address=new Address(3,city,state);
		expCity.add(address);
		
		city=new City(4,"CHENNAI");
		state=new State(3,"TAMIL NADU");
		address=new Address(4,city,state);
		expCity.add(address);
		
//		city=new City(5,"HYDERABAD");
//		state=new State(5,"TELANGANA");
//		address=new Address(5,city,state);
//		expCity.add(address);
//		
//		city=new City(6,"BANGALORE");
//		state=new State(2,"KARNATAKA");
//		address=new Address(6,city,state);
//		expCity.add(address);
		
		Mockito.when(addressRepository.findAll()).thenReturn(expCity);
		
	
		
		Assert.assertEquals(expCity, addressRepoService.allAddress());
		
		
	}

}
