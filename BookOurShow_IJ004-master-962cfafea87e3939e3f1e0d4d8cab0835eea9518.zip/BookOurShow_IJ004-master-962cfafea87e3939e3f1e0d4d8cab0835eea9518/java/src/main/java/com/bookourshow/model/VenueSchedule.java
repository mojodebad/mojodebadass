package com.bookourshow.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;

@Entity(name="venue_schedule")
@NamedNativeQueries({
	@NamedNativeQuery(name="VenueSchedule.getVenueScheduleId",query="select vs.venue_schedule_id "
			 +"from address a join venue v join venue_schedule vs join  movie_category mc join language l join movie m join timings t "
			 +"on v.fk_address_id=a.address_id and vs.fk_venue_id=v.venue_id and "
			 +"vs.fk_movie_category_id=mc.movie_category_id and mc.fk_language_id = l.language_id and "
			 +"mc.fk_movie_id=m.movie_id and t.timing_id=vs.fk_timings_id "
			 +"where m.movie_id=? and a.fk_city_id=? and l.language_id=? and v.venue_id=? and t.timing_id=?;"),
	@NamedNativeQuery(name="VenueSchedule.getVenueSchedule",query="select * "+
		 	  "from address a join venue v join venue_schedule vs join  movie_category mc join language l join movie m join timings t "+
		 	  "on v.fk_address_id=a.address_id and vs.fk_venue_id=v.venue_id and "+
		 	  "vs.fk_movie_category_id=mc.movie_category_id and mc.fk_language_id = l.language_id and "+
		 	  "mc.fk_movie_id=m.movie_id and t.timing_id=vs.fk_timings_id "+
		 	  "where vs.venue_schedule_id=?;")
})
public class VenueSchedule {
	
	@Id
	@Column(name="venue_schedule_id")
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int venueScheduleId;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_screen_id")
	private Screen screen;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_venue_id")
	private Venue venue;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_timings_id")
	private Timings timings;
	
	@ManyToOne(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	@JoinColumn(name="fk_movie_category_id")
	private MovieCategory moviecategory;

	public VenueSchedule() {
		// TODO Auto-generated constructor stub
	}
	
	public VenueSchedule(int venueScheduleId, Screen screen, Venue venue, Timings timings,
			MovieCategory moviecategory) {
		super();
		this.venueScheduleId = venueScheduleId;
		this.screen = screen;
		this.venue = venue;
		this.timings = timings;
		this.moviecategory = moviecategory;
	}

	public int getVenueScheduleId() {
		return venueScheduleId;
	}

	public void setVenueScheduleId(int venueScheduleId) {
		this.venueScheduleId = venueScheduleId;
	}

	public Screen getScreen() {
		return screen;
	}

	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	public Venue getVenue() {
		return venue;
	}

	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public Timings getTimings() {
		return timings;
	}

	public void setTimings(Timings timings) {
		this.timings = timings;
	}

	public MovieCategory getMoviecategory() {
		return moviecategory;
	}

	public void setMoviecategory(MovieCategory moviecategory) {
		this.moviecategory = moviecategory;
	}

	@Override
	public String toString() {
		return "VenueSchedule [venueScheduleId=" + venueScheduleId + ", timings=" + timings + ", moviecategory="
				+ moviecategory + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((moviecategory == null) ? 0 : moviecategory.hashCode());
		result = prime * result + ((timings == null) ? 0 : timings.hashCode());
		result = prime * result + venueScheduleId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VenueSchedule other = (VenueSchedule) obj;
		if (moviecategory == null) {
			if (other.moviecategory != null)
				return false;
		} else if (!moviecategory.equals(other.moviecategory))
			return false;
		if (timings == null) {
			if (other.timings != null)
				return false;
		} else if (!timings.equals(other.timings))
			return false;
		if (venueScheduleId != other.venueScheduleId)
			return false;
		return true;
	}

}
