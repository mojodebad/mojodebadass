package com.bookourshow.repo;

public class TimingRepoService {

	public TimingRepoService() {
		// TODO Auto-generated constructor stub
	}

}
