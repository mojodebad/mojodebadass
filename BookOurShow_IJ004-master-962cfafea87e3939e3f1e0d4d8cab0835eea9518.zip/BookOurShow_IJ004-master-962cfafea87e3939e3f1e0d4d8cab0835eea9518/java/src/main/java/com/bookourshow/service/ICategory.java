package com.bookourshow.service;

public interface ICategory {
	public String fetchCategoryName(int categoryId);
}
