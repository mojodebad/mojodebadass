package com.bookourshow.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Booking;
import com.bookourshow.model.Receipt;


public class ReceiptRepoService {

	public ReceiptRepoService() {
		// TODO Auto-generated constructor stub
	}

	@Autowired(required = true)
	ReceiptRepository receiptRepository;
	public List<String> fetchAllSeats()
	{
		Object[][] list= receiptRepository.fetchAllSeats();
		List<String> allSeatList=new ArrayList<String>();
		for(Object[] obj : list)
		{
			String seat=String.valueOf(obj[0])+String.valueOf(obj[1]);
			allSeatList.add(seat);
		}
		return allSeatList;
		
	}

	public List<String> fetchBookedSeats(@Param("fk_venue_schedule_id") int venueScheduleId,
			@Param("bookdate") String bookDate) {
		
		Object[][] list= receiptRepository.fetchBookedSeats(venueScheduleId, bookDate);
		List<String> bookedSeatList=new ArrayList<String>();
		for(Object[] obj : list)
		{
			String seat=String.valueOf(obj[1])+String.valueOf(obj[0]);
			bookedSeatList.add(seat);
		}
		return bookedSeatList;
		
	}
	
	public Receipt registerReceipt(Receipt receipt){
		
		int flag=0;
		Receipt recep=  receiptRepository.save(receipt);
		if(recep!=null){
			return recep;
			
		}else{
			return  null;
		}
		
	}

}
