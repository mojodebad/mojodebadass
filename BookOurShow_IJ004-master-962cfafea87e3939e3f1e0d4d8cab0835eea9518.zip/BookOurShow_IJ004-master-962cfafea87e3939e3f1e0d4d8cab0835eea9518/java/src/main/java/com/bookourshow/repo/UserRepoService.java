package com.bookourshow.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.bookourshow.model.User;

@Service
	public class UserRepoService{
		public UserRepoService(){}
		@Autowired(required=true)
		UserRepository userRepository;
		public Object[][] fetchUserByIdandPassword(@Param("email") String email,@Param("password") String password)
		{
			System.out.println(userRepository.fetchUserByIdandPassword(email, password));
			return userRepository.fetchUserByIdandPassword(email, password);
		}
		public User registerUser(User user)
		{
			return userRepository.save(user);
		}

	}

