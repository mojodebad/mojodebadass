package com.bookourshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookourshow.model.Address;
import com.bookourshow.model.MovieCategory;

public interface MovieCategoryRepository extends JpaRepository<MovieCategory, Integer> {
	public Object[][]  fetchAllMovie();
	
}
