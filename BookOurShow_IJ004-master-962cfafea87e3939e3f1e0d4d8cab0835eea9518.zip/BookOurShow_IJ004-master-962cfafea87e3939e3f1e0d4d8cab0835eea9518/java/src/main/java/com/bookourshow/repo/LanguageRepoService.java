package com.bookourshow.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Language;

public class LanguageRepoService {

	public LanguageRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	LanguageRepository languageRepository;
	public Set<Language> fetchLanguageByMovieAndCity(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId){
		
		Object[][] list = languageRepository.fetchLanguageByMovieAndCity(movieId, cityId);
		Set<Language> languageList=new HashSet<Language>();
		for(Object[] obj:list){
				Language language=new Language(Integer.parseInt(String.valueOf(obj[0])),String.valueOf(obj[1]));
				languageList.add(language);
		}
		
		
		return languageList;
	}
	
	/*public Set<Language> fetchLanguageByMovieAndCity(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId){
		return languageRepository.fetchLanguageByMovieAndCity(movieId, cityId);
	}*/
	
}
