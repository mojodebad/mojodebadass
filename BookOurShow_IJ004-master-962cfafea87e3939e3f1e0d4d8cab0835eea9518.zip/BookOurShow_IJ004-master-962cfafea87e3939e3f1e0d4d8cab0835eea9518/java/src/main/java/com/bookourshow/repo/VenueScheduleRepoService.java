package com.bookourshow.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

public class VenueScheduleRepoService {

	public VenueScheduleRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	VenueScheduleRepository venueScheduleRepository;
	
	public int getVenueScheduleId(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId,@Param("language_id") int languageId,@Param("venue_id") int venueId,@Param("timing_id") int timingId){
		return venueScheduleRepository.getVenueScheduleId(movieId, cityId, languageId, venueId, timingId);
	}

}
