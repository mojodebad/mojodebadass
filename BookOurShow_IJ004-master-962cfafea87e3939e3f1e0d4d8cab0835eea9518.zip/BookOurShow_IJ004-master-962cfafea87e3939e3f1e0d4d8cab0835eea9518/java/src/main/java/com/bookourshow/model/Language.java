package com.bookourshow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.EnabledIf;


@NamedNativeQueries({
	@NamedNativeQuery(
			name="Language.fetchLanguageName",
			query="select language_name from language where language_id=?"
	),
	@NamedNativeQuery(
			name="Language.fetchLanguageByMovieAndCity",
			/*query="select m.movie_name,group_concat(distinct (l.language_id)) as languages,group_concat(mc.movie_category_id),group_concat(distinct(v.venue_name)), group_concat(vs.fk_timings_id) "
				+ "from address a join venue v join venue_schedule vs join  movie_category mc join language l join movie m on "
				+ "v.fk_address_id=a.address_id and vs.fk_venue_id=v.venue_id and "
				+ "vs.fk_movie_category_id=mc.movie_category_id and mc.fk_language_id = l.language_id and "
				+ "mc.fk_movie_id=m.movie_id where m.movie_id=? and a.fk_city_id=? " + "group by m.movie_id"*/
			
			query="select l.* as languages "
					+ "from address a join venue v join venue_schedule vs join  movie_category mc join language l join movie m on "
					+ "v.fk_address_id=a.address_id and vs.fk_venue_id=v.venue_id and "
					+ "vs.fk_movie_category_id=mc.movie_category_id and mc.fk_language_id = l.language_id and "
					+ "mc.fk_movie_id=m.movie_id where m.movie_id=? and a.fk_city_id=? "
	)
})
@Entity(name="language")
public class Language {
	
	@Id
	@Column(name="language_id")
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int languageId;
	
	@Column(name="language_name")
	private String languageName;
	
	public Language() {
		// TODO Auto-generated constructor stub
	}

	public Language(int languageId, String languageName) {
		super();
		this.languageId = languageId;
		this.languageName = languageName;
	}

	public int getLanguageId() {
		return languageId;
	}
	@Autowired
	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public String getLanguageName() {
		return languageName;
	}
	@Autowired
	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}

	@Override
	public String toString() {
		return "Language [languageId=" + languageId + ", languageName=" + languageName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + languageId;
		result = prime * result + ((languageName == null) ? 0 : languageName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Language other = (Language) obj;
		if (languageId != other.languageId)
			return false;
		if (languageName == null) {
			if (other.languageName != null)
				return false;
		} else if (!languageName.equals(other.languageName))
			return false;
		return true;
	}
	
	
}
