package com.bookourshow.repo;

public class CategoryRepoService {

	public CategoryRepoService() {
		// TODO Auto-generated constructor stub
	}

}
