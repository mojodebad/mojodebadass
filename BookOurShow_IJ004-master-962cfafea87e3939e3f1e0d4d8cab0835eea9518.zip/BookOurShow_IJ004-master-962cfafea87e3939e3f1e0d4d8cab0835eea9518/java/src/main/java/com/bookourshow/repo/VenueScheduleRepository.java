package com.bookourshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.VenueSchedule;

public interface VenueScheduleRepository extends JpaRepository<VenueSchedule, Integer> {
	public int getVenueScheduleId(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId,@Param("language_id") int languageId,@Param("venue_id") int venueId,@Param("timing_id") int timingId);
}
