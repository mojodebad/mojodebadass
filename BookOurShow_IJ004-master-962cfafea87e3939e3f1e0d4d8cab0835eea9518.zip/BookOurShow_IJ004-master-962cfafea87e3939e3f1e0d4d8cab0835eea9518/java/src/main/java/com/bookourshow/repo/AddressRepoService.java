package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookourshow.model.Address;
import com.bookourshow.model.City;

@Service
public class AddressRepoService {

	public AddressRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	AddressRepository addressRepository;
	
	public List<Address> allAddress(){
		/*List<Address> list = addressRepository.fetchAllLocation();*/
		List<Address> list=addressRepository.findAll();
		return list;
	}
	
}
