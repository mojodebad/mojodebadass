package com.bookourshow.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bookourshow.model.Booking;

public class BookingRepoService {

	public BookingRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	BookingRepository bookingRepository;
	//@Param("fk_user_id") int userId,@Param("fk_venue_schedule_id") int venueScheduleId,@Param("bookdate") String bookDate
	public Booking registerBooking(Booking booking){
		
		int flag=0;
		Booking book=  bookingRepository.save(booking);
		if(book!=null){
			return book;
			
		}else{
			return  null;
		}
		
	}
	public Booking generateBill(@Param("fk_booking_id") int bookingId)
	{
		Object[][] booking=bookingRepository.generateBill(bookingId);
		Booking book=null;
		for(Object[] obj:booking){
			book=new Booking(Integer.parseInt(String.valueOf(obj[0])),Float.parseFloat(String.valueOf(obj[1])),Integer.parseInt(String.valueOf(obj[2])));
		}
		return book;
	}
	public Booking fetchBooking(int bookingId){
		Optional<Booking> result=bookingRepository.findById(bookingId);
		if(result.isPresent()){
			System.out.println(result.get());
			return result.get();}
		else
			return null;
	}
	public void deleteBooking(int bookingId){
		bookingRepository.deleteById(bookingId);
	}
}
