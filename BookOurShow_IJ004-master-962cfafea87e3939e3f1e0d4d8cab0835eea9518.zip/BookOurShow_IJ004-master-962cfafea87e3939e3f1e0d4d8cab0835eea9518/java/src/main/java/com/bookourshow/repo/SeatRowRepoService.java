package com.bookourshow.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.SeatRow;

public class SeatRowRepoService {

	public SeatRowRepoService() {
		// TODO Auto-generated constructor stub
	}
	
	@Autowired(required=true)
	SeatRowRepository seatRowRepository;
	
	public SeatRow getRowId(@Param("row_code") String rowCode){
		
		Object[][] objArray=seatRowRepository.getRowId(rowCode);
		SeatRow seatRow=null;
		for (Object[] obj:objArray)
		{
			seatRow=new SeatRow(Integer.parseInt(String.valueOf(obj[0])),String.valueOf(obj[1]));
		}
		return seatRow;
	}
}
