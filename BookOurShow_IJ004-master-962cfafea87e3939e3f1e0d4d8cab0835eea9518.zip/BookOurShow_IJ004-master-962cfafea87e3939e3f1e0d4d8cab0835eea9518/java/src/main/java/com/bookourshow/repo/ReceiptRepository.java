package com.bookourshow.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Receipt;

public interface ReceiptRepository extends JpaRepository<Receipt,Integer> {
	public Object[][] fetchAllSeats();
	public Object[][] fetchBookedSeats(@Param("fk_venue_schedule_id") int venueScheduleid, @Param("bookdate") String bookDate);

}
