package com.bookourshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Address;
import com.bookourshow.model.SeatRow;

public interface SeatRowRepository extends JpaRepository<SeatRow, Integer>{
	public Object[][] getRowId(@Param("row_code") String rowCode);
}
