package com.bookourshow.repo;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Language;

public interface LanguageRepository extends JpaRepository<Language, Integer> {
	public Object[][] fetchLanguageByMovieAndCity(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId);
	
	/*public Set<Language> fetchLanguageByMovieAndCity(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId);*/
}
