package com.bookourshow.repo;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.bookourshow.model.Movie;
import com.bookourshow.model.MovieCategory;

import ch.qos.logback.core.net.SyslogOutputStream;

public class MovieCategoryRepoService {

	public MovieCategoryRepoService() {
		// TODO Auto-generated constructor stub
	}

	@Autowired(required = true)
	MovieCategoryRepository movieCategoryRepository;

	public List<MovieCategory> fetchAllMovie() {
		Object[][] list = movieCategoryRepository.fetchAllMovie();
		List<MovieCategory> listMovie=new ArrayList<MovieCategory>();
		for(Object[] obj:list){
				MovieCategory movieCategory=new MovieCategory(String.valueOf(obj[0]), new Movie(Integer.parseInt( String.valueOf(obj[1])),String.valueOf(obj[2]),String.valueOf(obj[3])),String.valueOf(obj[4]));
				listMovie.add(movieCategory);
		}
//		Map<Movie,List<MovieCategory>> userMap=list.stream().collect(Collectors.groupingBy(MovieCategory::getMovie));

		
		return listMovie;
	}
}
