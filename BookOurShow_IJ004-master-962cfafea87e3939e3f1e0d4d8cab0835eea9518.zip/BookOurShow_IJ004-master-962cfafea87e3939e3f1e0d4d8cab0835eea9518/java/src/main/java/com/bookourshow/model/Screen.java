package com.bookourshow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="screen")
public class Screen {
	
	@Id
	@Column(name="screen_id")
	@GeneratedValue( strategy = GenerationType.IDENTITY)
	private int screenId;
	
	@Column(name="screen_code")
	private String screenCode;
	
	
	public Screen() {
		super();
	}
	public int getScreenId() {
		return screenId;
	}
	public Screen(int screenId, String screenCode) {
		super();
		this.screenId = screenId;
		this.screenCode = screenCode;
	}
	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}
	public String getScreenCode() {
		return screenCode;
	}
	public void setScreenCode(String screenCode) {
		this.screenCode = screenCode;
	}
	@Override
	public String toString() {
		return "Screen [screenId=" + screenId + ", screenCode=" + screenCode + "]";
	}
	

}
