package com.bookourshow.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bookourshow.model.Movie;

public class MovieRepoService {

	public MovieRepoService() {
		// TODO Auto-generated constructor stub
	}

	@Autowired(required = true)
	MovieRepository movieRepository;
	
	public List<Movie> fetchMovies(){
		return movieRepository.findAll();
	}
}
