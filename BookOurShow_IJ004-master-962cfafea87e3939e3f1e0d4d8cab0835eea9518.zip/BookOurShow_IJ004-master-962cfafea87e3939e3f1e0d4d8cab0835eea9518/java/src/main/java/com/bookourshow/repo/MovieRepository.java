package com.bookourshow.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bookourshow.model.Movie;

public interface MovieRepository extends JpaRepository<Movie, Integer> {

}
