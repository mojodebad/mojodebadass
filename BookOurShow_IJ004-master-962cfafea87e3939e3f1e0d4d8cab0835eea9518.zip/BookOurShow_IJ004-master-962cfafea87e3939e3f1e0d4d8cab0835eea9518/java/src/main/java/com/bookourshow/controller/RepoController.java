package com.bookourshow.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookourshow.model.Address;
import com.bookourshow.model.Booking;
import com.bookourshow.model.City;
import com.bookourshow.model.Language;
import com.bookourshow.model.Movie;
import com.bookourshow.model.MovieCategory;
import com.bookourshow.model.Receipt;
import com.bookourshow.model.SeatColumn;
import com.bookourshow.model.SeatRow;
import com.bookourshow.model.User;
import com.bookourshow.model.Venue;
import com.bookourshow.repo.AddressRepoService;
import com.bookourshow.repo.BookingRepoService;
import com.bookourshow.repo.CategoryRepoService;
import com.bookourshow.repo.LanguageRepoService;
import com.bookourshow.repo.MovieCategoryRepoService;
import com.bookourshow.repo.MovieRepoService;
import com.bookourshow.repo.ReceiptRepoService;
import com.bookourshow.repo.SeatRowRepoService;
import com.bookourshow.repo.TimingRepoService;
import com.bookourshow.repo.UserRepoService;
import com.bookourshow.repo.VenueRepoService;
import com.bookourshow.repo.VenueScheduleRepoService;

@RestController
@CrossOrigin
public class RepoController {

	@Autowired(required=true)
	AddressRepoService addressRepoService;
	
	@Autowired(required=true)
	BookingRepoService bookingRepoService;
	
	@Autowired(required=true)
	CategoryRepoService categoryRepoService;
	
	@Autowired(required=true)
	LanguageRepoService languageRepoService;
	
	@Autowired(required=true)
	MovieCategoryRepoService movieCategoryRepoService;
	
	@Autowired(required=true)
	MovieRepoService movieRepoService;
	
	@Autowired(required=true)
	ReceiptRepoService receiptRepoService;
	
	@Autowired(required=true)
	TimingRepoService timingRepoService;
	
	@Autowired(required=true)
	UserRepoService userRepoService;
	
	@Autowired(required=true)
	VenueRepoService venueRepoService;
	
	@Autowired(required=true)
	VenueScheduleRepoService venueScheduleRepoService;
	
	@Autowired(required=true)
	SeatRowRepoService seatRowRepoService;
	
	@GetMapping("/alladdress")
	public List<Address> allAddress(){
		List<Address> list =addressRepoService.allAddress();
		return list;
	}
	@GetMapping("/movies")
	public List<Movie> fetchMovies(){
		return movieRepoService.fetchMovies();
	}
	@GetMapping("/allmovies")
	public List<MovieCategory> fetchAllMovie(){
		List<MovieCategory> list=movieCategoryRepoService.fetchAllMovie();
		return list;
		
	}
	
	@GetMapping("/languagebycityandmovie/{cityId}/{movieId}")
	public Set<Language> fetchLanguageByMovieAndCity(@PathVariable int cityId,@PathVariable int movieId){
		Set<Language> list=languageRepoService.fetchLanguageByMovieAndCity(movieId,cityId);
		System.out.println("--------->"+list);
		return list;
	}
	
	/*@PostMapping("/languagebycityandmovie")
	public List<Language> fetchLanguageByMovieAndCity(@RequestBody String[] parameterFetch){
		int movieId=Integer.parseInt(parameterFetch[0]);
		int cityId=Integer.parseInt(parameterFetch[1]);
		return languageRepoService.fetchLanguageByMovieAndCity(movieId,cityId);
	}*/
	@GetMapping("/venuebycityandmovieandlanguage/{cityId}/{movieId}/{languageId}")
	public Map<String,List<Venue>> fetchTheaters(@PathVariable int cityId,@PathVariable int movieId,@PathVariable int languageId){
		
		return venueRepoService.fetchTheaters(movieId, cityId, languageId);
		
	}
	@GetMapping("/venuescheduleId/{cityId}/{movieId}/{languageId}/{venueId}/{timingId}")
	public int getVenueScheduleId(@PathVariable int cityId,@PathVariable int movieId,@PathVariable int languageId,@PathVariable int venueId,@PathVariable int timingId){
		return venueScheduleRepoService.getVenueScheduleId(movieId, cityId, languageId, venueId, timingId);
	}
	@GetMapping("/fetchAllSeats")
	public List<String> fetchAllSeats()
	{
		return receiptRepoService.fetchAllSeats();
	}
	@GetMapping("/fetchallbookedseats/{venueScheduleId}/{bookDate}")
	public List<String> fetchBookedSeats(@PathVariable int venueScheduleId,@PathVariable String bookDate){
		
		return receiptRepoService.fetchBookedSeats(venueScheduleId, bookDate);
		
	}
	@PostMapping("/booking")//@PathVariable int userId,@PathVariable int venueScheduleId,@PathVariable String bookDate
	public Booking registerBooking(@RequestBody Booking booking){
		return bookingRepoService.registerBooking(booking);
	}
	@PostMapping("/updateReceipt/{bookingId}")
	public Booking updateReceipt(@PathVariable int bookingId,@RequestBody String[] parameterFetch)
	{
		Booking booking = new Booking();
		booking=bookingRepoService.fetchBooking(bookingId);
		//booking.setBookingId(bookingId);
		SeatColumn seatColumn = null;
		SeatRow seatRow = null;
		List<SeatRow> rowList=new ArrayList<>();
		List<SeatColumn> colList=new ArrayList<>();
		List<Receipt> receiptList=new ArrayList<>();
		for(String seat: parameterFetch)
		{
			//System.out.println(seat);
			char seatRowChar = seat.charAt(0);
			String seatRowCode = Character.toString(seatRowChar);
			System.out.println("row--->"+seatRowCode);
			
			char seatCol = seat.charAt(1);
			String seatColumnCode = Character.toString(seatCol);
			System.out.println("col code---->"+seatColumnCode);
			
			int seatColumnId = Integer.parseInt(seatColumnCode);
			seatColumn = new SeatColumn(seatColumnId, seatColumnCode);
			//colList.add(seatColumn);
			
			SeatRow row=seatRowRepoService.getRowId(seatRowCode);
			/*System.out.println("seat row---->"+row);
			rowList.add(row);*/
			
			Receipt receipt = new Receipt(booking, seatColumn, row);
			Receipt receiptObj=receiptRepoService.registerReceipt(receipt);
			System.out.println("Receipt--->"+receiptObj);
			receiptList.add(receiptObj);
		}
		Booking bookingObj=bookingRepoService.generateBill(bookingId);
		System.out.println("BOOKING ------->"+bookingObj);
		booking.setNoOfSeats(bookingObj.getNoOfSeats());
		booking.setAmount(bookingObj.getAmount());
		
		bookingObj=bookingRepoService.registerBooking(booking);
		//System.out.println("LIST----->"+receiptList);
		System.out.println("FINAL BOOKING ------->"+bookingObj);
		return bookingObj;
	}
	
	@GetMapping("/fetchBooking/{bookingId}")
	public Booking fetchBooking(@PathVariable int bookingId){
		return bookingRepoService.fetchBooking(bookingId);
	}
	/*@PostMapping("/generatebill")
	public List<Booking> generateBill(@RequestBody String[] parameterFetch){
		int bookingId=Integer.parseInt(parameterFetch[0]);
		return bookingRepoService.generateBill(bookingId);
	}*/
	

	@PostMapping("/fetchUserByIdandPassword")
	public User fetchUserByIdandPassword(@RequestBody User user)
	{
		System.out.println(user.getEmail()+user.getPassword());
		User getUser=null;
		boolean flag=false;
		Object[][] arr = userRepoService.fetchUserByIdandPassword(user.getEmail(), user.getPassword());
		
			for(Object[] objArr: arr){
				System.out.println("asdg"+objArr.length);
				if(objArr.length !=0)
				{
					flag=true;
					getUser= new User(Integer.parseInt(String.valueOf(objArr[0])),String.valueOf(objArr[1]),String.valueOf(objArr[2]),String.valueOf(objArr[3]));
				}
			}
			if(flag==false)
			{
				getUser=  new User();
				
			}
		System.out.println(getUser.getEmail()+"asdf"+getUser.getPassword());
		return getUser;
			
	}
	@PostMapping("/registerUser")
	public User registerUser(@RequestBody User user)
	{
		return userRepoService.registerUser(user); 
	}
	@DeleteMapping("/deleteBooking/{bookingId}")
	public Booking deleteBooking(@PathVariable int bookingId){
		bookingRepoService.deleteBooking(bookingId);
		Booking booking=new Booking();
		booking.setBookingId(bookingId);
		return booking;
	}
}
