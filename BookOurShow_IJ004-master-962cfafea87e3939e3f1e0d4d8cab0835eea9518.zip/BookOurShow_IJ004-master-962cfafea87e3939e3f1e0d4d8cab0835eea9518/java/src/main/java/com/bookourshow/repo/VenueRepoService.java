package com.bookourshow.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;

import com.bookourshow.model.Language;
import com.bookourshow.model.Timings;
import com.bookourshow.model.Venue;

public class VenueRepoService {

	public VenueRepoService() {
		// TODO Auto-generated constructor stub
	}
	@Autowired(required=true)
	VenueRepository venueRepository;
	public Map<String,List<Venue>> fetchTheaters(@Param("movie_id") int movieId,@Param("fk_city_id") int cityId,@Param("language_id") int languageId)
	{
		Object[][] list = venueRepository.fetchTheaters(movieId, cityId, languageId);
		//Set<Language> languageList=new HashSet<Language>();
//		Map<Integer, List<Venue>> venueMap=null;
		List<Venue> venueList=new ArrayList<Venue>();
		for(Object[] obj:list){
			Timings timings=new Timings(Integer.parseInt(String.valueOf(obj[2])),String.valueOf(obj[3]),String.valueOf(obj[4]));
			Venue venue= new Venue(Integer.parseInt(String.valueOf(obj[0])),String.valueOf(obj[1]),timings);
			venueList.add(venue);
		}
		Map<String,List<Venue>> userMap=venueList.stream().collect(Collectors.groupingBy(Venue::getVenueName));

		return userMap;
	}
}
