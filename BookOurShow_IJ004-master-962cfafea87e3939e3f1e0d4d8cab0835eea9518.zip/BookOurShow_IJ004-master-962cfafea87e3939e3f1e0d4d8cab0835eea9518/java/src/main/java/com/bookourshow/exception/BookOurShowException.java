package com.bookourshow.exception;

public class BookOurShowException extends Exception {
	public BookOurShowException() {
		// TODO Auto-generated constructor stub
	}

	public BookOurShowException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
