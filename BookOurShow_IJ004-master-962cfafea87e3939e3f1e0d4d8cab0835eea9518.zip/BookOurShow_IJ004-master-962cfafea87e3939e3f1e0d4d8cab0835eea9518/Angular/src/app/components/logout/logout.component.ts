import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

      constructor(private router:Router) { }

      //this page directly routes to Login page--------------------------------------------------
      //removes the user details from local storage----------------------------------------------

      ngOnInit() {
          localStorage.removeItem("user");
          localStorage.removeItem("bookDate");
          this.router.navigate(["/login"]);
      }

}
