import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
  })


  //the service class contains all the get and post request to interact with backend i.e fetching and posting Data---------------


export class BookOurShowService{

    constructor(private _http:HttpClient) { }
   
    fetchLocation():any{
        return this._http.get("http://localhost:1111/alladdress");
    }

    fetchMovie():any{
        return this._http.get("http://localhost:1111/allmovies");
    }
 
    fetchLanguage(cityId:any,movieId:any):any{
        return this._http.get("http://localhost:1111/languagebycityandmovie/"+cityId+"/"+movieId);
    }
    
    fetchVenue(cityId:any,movieId:any,languageId:any):any{
        return this._http.get("http://localhost:1111/venuebycityandmovieandlanguage/"+cityId+"/"+movieId+"/"+languageId);
    }
    
    fetchVenueScheduleId(cityId:any,movieId:any,languageId:any,venueId:any,timingId:any):any
    {
        return this._http.get("http://localhost:1111/venuescheduleId/"+cityId+"/"+movieId+"/"+languageId+"/"+venueId+"/"+timingId);
    }
    
    fetchallSeats():any
    {
        return this._http.get("http://localhost:1111/fetchAllSeats");
    }
  
    fetchBookedSeats(venueScheduleId,bookDate):any
    {
        return this._http.get("http://localhost:1111/fetchallbookedseats/"+venueScheduleId+"/"+bookDate);
    }
    registerBooking(booking:any):any{
        return this._http.post("http://localhost:1111/booking",booking);
    }
    updateReceipt(bookingId:any,seats:any):any{
        return this._http.post("http://localhost:1111/updateReceipt/"+bookingId,seats);
    }
    fetchBookingDetails(bookingId:any):any{
        return this._http.get("http://localhost:1111/fetchBooking/"+bookingId);
    }
    validateUser(data)
    {
        return this._http.post("http://localhost:1111/fetchUserByIdandPassword",data);
    }
    registerUser(data)
    {
        return this._http.post("http://localhost:1111/registerUser",data);
    }

    setUser(user:string)
    {
        localStorage.setItem('currentUser',JSON.stringify({'username':user}));          
    }

    getUser():any
    {
        return localStorage.getItem('currentUser');
    }

    logout()
    {
        localStorage.removeItem('currentUser');
    }
}