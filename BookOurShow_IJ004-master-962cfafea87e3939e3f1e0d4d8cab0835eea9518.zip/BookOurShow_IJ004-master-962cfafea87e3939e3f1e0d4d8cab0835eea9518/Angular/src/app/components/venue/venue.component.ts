import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookOurShowService } from '../services/bookshow.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-venue',
  templateUrl: './venue.component.html',
  styleUrls: ['./venue.component.css']
})
export class VenueComponent implements OnInit {

       cityId:any;
       movieId:any;
       languageId:any;
       venueList:any;
       venueScheduleId:any;
       constructor(private route:ActivatedRoute,private service:BookOurShowService,private router:Router) { }

      //fetches city ,movie , language info to asses in which venue the picture is available on which theatres-------------
       
        ngOnInit() {
                this.cityId=this.route.snapshot.paramMap.get("cityId");
                console.log("CITY ID---->"+this.cityId);
                this.movieId=this.route.snapshot.paramMap.get("movieId");
                console.log("MOVIE ID---->"+this.movieId);
                this.languageId=this.route.snapshot.paramMap.get("languageId");
                console.log("LANGUAGE ID---->"+this.languageId);

                this.service.fetchVenue(this.cityId,this.movieId,this.languageId).subscribe(
                  (res)=>{
                      console.log(res+" Success ");
                      this.venueList=res;
                  },(error:HttpErrorResponse)=>{
                        console.log(error+" Failure ");
                        if(error instanceof Error)
                        {
                            console.log("Client side error "+error);
                        }
                        else
                        {
                            console.log("Server side error "+error);
                        }
                  }
                );

      }
      
      //fetching  venue(movie hall ) and time slots for a particular movie--------------------
      
      onClick(venueId,timingId):any{
      this.service.fetchVenueScheduleId(this.cityId,this.movieId,this.languageId,venueId,timingId).subscribe(
            (res)=>{
                  console.log(res+" Success ");
                  this.venueScheduleId=res;
                  var bookDate=localStorage.getItem("bookDate");
                  this.router.navigate(['/seats',this.venueScheduleId,bookDate]);
            },
            (error:HttpErrorResponse)=>{
                  console.log(error+" Failure ");
                  if(error instanceof Error)
                  {
                      console.log("Client side error "+error);
                  }
                  else
                  {
                      console.log("Server side error "+error);
                  }
            }
      );
        
      }

}
