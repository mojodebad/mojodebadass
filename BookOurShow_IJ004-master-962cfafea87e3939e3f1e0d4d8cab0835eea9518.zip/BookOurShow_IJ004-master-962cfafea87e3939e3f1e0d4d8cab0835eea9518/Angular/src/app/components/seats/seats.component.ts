import { Component, OnInit } from '@angular/core';
import { BookOurShowService } from '../services/bookshow.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { Login } from '../model/login';

@Component({
  selector: 'app-seats',
  templateUrl: './seats.component.html',
  styleUrls: ['./seats.component.css']
})
export class SeatsComponent implements OnInit 
{
      private allSeats:any;
      private bookedSeats:any;
      private venueScheduleId:any;
      private bookDate:any;
      newBookedSeats:Array<string> =new Array();
      bookingDetails:any;
      private flag:boolean;
      userId:any;
      finalBooking:any;
      seatColor:any;
      changecolor:boolean;
      user:any;
      value:boolean;
      constructor(private service:BookOurShowService,private route:ActivatedRoute,private router:Router) { }

      ngOnInit() {
            //takes venueScheduleId from activated route
            this.venueScheduleId=this.route.snapshot.paramMap.get("venueScheduleId");
            //takes bookDate from activeactivated route
            this.bookDate=this.route.snapshot.paramMap.get("bookDate");
            //ftches all seats in the selected venue
            this.service.fetchallSeats().subscribe(
                  (res)=>{
                      console.log(res+" Success ");
                      this.allSeats=res;
                  },
                  (error:HttpErrorResponse)=>{
                      console.log(error+" Failure ");
                      if(error instanceof Error)
                      {
                          console.log("Client side error "+error);
                      }
                      else
                      {
                          console.log("Server side error "+error);
                      }
                  }
            );
            //fetches booked seats in the selected list
            this.service.fetchBookedSeats(this.venueScheduleId,this.bookDate).subscribe(
                  (res)=>
                  {
                      console.log(res+" Success ");
                      this.bookedSeats=res;
                  },
                  (error:HttpErrorResponse)=>
                  {
                      console.log(error+" Failure ");
                      if(error instanceof Error)
                      {
                          console.log("Client side error "+error);
                      }
                      else
                      {
                        console.log("Server side error "+error);
                      }
                  }
            );

      }
     //checks whether a particular seat is there in booked seats or not.
     //acoording the returned value the colour of seat if defined.
      isPresent(seat){
            if(this.bookedSeats.includes(seat))
            {
              return true;
            }
            return false;
      }
     //checks whether the selected seat is there in newlybooked seats or not 
     //if it is there then the selection represents deselction of aselected seat
     //else the selection represents selection of a new seat.
      check(seat:any)
      {

          if(this.newBookedSeats.includes(seat)){
            var index=this.newBookedSeats.indexOf(seat);
            this.newBookedSeats.splice(index,1);
            var result = document.getElementById(seat);
            result.style.color="green";
          }
          else{
            this.newBookedSeats.push(seat);
            var result = document.getElementById(seat);
            result.style.color="grey";
          }
      }
       
      verify():any{
        this.value=false;
        if(this.newBookedSeats.length==0){
          this.value=true;
        }
        else{
          this.value=false;
        }
        return this.value;
  }

      //this functions add details in the booking table when book now button is pressed it generates bill info for transaction-----------
      
      
      bookNow()
      {
            this.user=JSON.parse(localStorage.getItem("user"));
            console.log("USER------->"+this.user.userId);
            var booking={
                  "user": { "userId": this.user.userId},
                  "venueSchedule": {"venueScheduleId": this.venueScheduleId},
                  "bookDate": this.bookDate
                        };

            this.service.registerBooking(booking).subscribe(
                      (res)=>{
                                console.log(res+" Success ");
                                this.bookingDetails=res;
                                console.log("BOOKING SUCCESSFULL"+this.bookingDetails.bookingId);
                                this.service.updateReceipt(this.bookingDetails.bookingId,this.newBookedSeats).subscribe(
                                  (res)=>{
                                    console.log(res+" Success ");
                                    this.finalBooking=res;
                                    console.log("BOOKING:\n"+JSON.stringify(this.finalBooking));
                                    this.router.navigate(['/bill',this.finalBooking.bookingId],{queryParams:{seats:this.newBookedSeats}});
                                  },(error:HttpErrorResponse)=>{
                                    console.log(error+" Failure ");
                                    if(error instanceof Error){
                                        console.log("Client side error "+error);
                                    }
                                    else
                                    {
                                        console.log("Server side error "+error);
                                    }
                                  }
                                );
                      },
                      (error:HttpErrorResponse)=>{
                                console.log(error+" Failure ");
                                if(error instanceof Error)
                                {
                                        console.log("Client side error "+error);
                                }
                                else
                                {
                                         console.log("Server side error "+error);
                                }
                      }
            );

      }


      //the method is used for creation of  grid view of seats in the view ------------------------
      
      i=1;
      bFlag:boolean;
      breakLine():boolean{
        if(this.i!=4)
        {
            this.i++;
            this.bFlag=false;
        }
        else{
          this.i=1;
          this.bFlag=true;
        }
        return this.bFlag;
      }
}
