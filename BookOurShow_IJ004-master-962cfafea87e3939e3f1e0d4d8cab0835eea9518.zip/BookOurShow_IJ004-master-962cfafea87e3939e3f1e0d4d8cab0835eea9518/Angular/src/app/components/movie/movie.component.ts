import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookOurShowService } from '../services/bookshow.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Movie } from '../model/movie';
//import { Category } from '../model/category';
//import { Language } from '../model/language';
import { MovieCategory } from '../model/movie-category';
import { AppComponent } from '../../app.component';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  private cityId:any;
  private movieList:any;
  private movie:Movie=new Movie("","","");
  private category:string;
  private language:string;

  private movieCategory:MovieCategory=new MovieCategory("",this.movie,"","");

  constructor(private app: AppComponent,private _services:BookOurShowService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
        //this method fetches data from router parameters as soon as the  page is called that is city info------
        this.cityId=this.route.snapshot.paramMap.get("cityId");
        
        
        
        
        
        //fetches all movies from database.
        this._services.fetchMovie().subscribe(
              (res)=>{
                    console.log(res+" Success ");
                    this.movieList=res;
                    
                   
              },
              (error:HttpErrorResponse)=>
              {
                    console.log(error+" Failure ");
                    if(error instanceof Error){
                        console.log("Client side error "+error);
                    }
                    else
                    {
                        console.log("Server side error "+error);
                    }
              }
        );
  }

  // routes to language page with movie info and city information---------------------
  onBook(movieId:any){
        
        this.router.navigate(['/language',this.cityId,movieId]);
      
  }

}
