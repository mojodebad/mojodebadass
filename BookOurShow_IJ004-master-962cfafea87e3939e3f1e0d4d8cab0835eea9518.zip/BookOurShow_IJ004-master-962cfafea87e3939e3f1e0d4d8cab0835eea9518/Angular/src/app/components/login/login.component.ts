import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { AppComponent } from '../../app.component';
import { BookOurShowService } from '../services/bookshow.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

      private login:boolean=true;
      returnUrl:any;
      constructor(private app: AppComponent,private route:ActivatedRoute,private _loginService:BookOurShowService,private router:Router) { }
     
      
      ngOnInit() 
        {
            this.returnUrl=this.route.snapshot.queryParams['returnUrl'];
        }
  
        
    // generates variable fields to catch the login data -----------------------------------------------

  
      loginForm=new FormGroup(
      {
            email:new FormControl(''),
            password:new FormControl('')
      });


   // generates variable fields to catch the registering data------------------------------------------
      

      signupForm=new FormGroup(
      {
            userName:new FormControl(''),
            email: new FormControl(''),
            password:new FormControl('')
      });
    //method to be called after the submit button is pressed in signup page. 
        onSignUpSubmit()
        {
                //checking whether the data entered in the signup form is valid or not,or already present or not---------------
                //registers the user if he/she is a new user.            
                this._loginService.validateUser(this.signupForm.value).subscribe(
                        (res)=>{
                               this._loginService.registerUser(this.signupForm.value).subscribe(
                                    (res)=>{
                                        alert("REGISTERED SUCCESSFULLY !!!!");
                                        this._loginService.setUser(JSON.stringify(res));
                                        this.router.navigate(['/login']);
                                    },
                                    (error:HttpErrorResponse)=>
                                    {
                                        alert("some error in registering your data "+error);
                                        this.router.navigate['/login'];
                                    }
                               );
                          
                        },
                        (error:HttpErrorResponse)=>
                        {
                              console.log(error+" Failure ");
                              if(error instanceof Error)
                              {
                                  console.log("Client side error "+error);
                              }
                              else
                              {
                                  console.log("Server side error "+error);
                              }
                        }
              );
        }


        //on submit method is  triggered as we hit the submit button in Login  form---------------------------
        //checking whether the data entered in the signup form is valid or not.
        //stores the userdetails in the local storage of the browser.
        onLoginSubmit()
        {
            this._loginService.validateUser(this.loginForm.value).subscribe(
                      (res)=>
                      {
                                if(res["email"]!=null&&res["password"]!=null)
                                {
                                      localStorage.setItem("user",JSON.stringify(res));
                                      if(this.returnUrl==null)
                                      {
                                        this.router.navigate(['/location']);
                                      }
                                      else
                                      {
                                        this.router.navigateByUrl(this.returnUrl);
                                      }
                                }
                                else
                                {
                                      alert("Invalid credentials or unregistered user");
                                
                                }
                      },
                      (error:HttpErrorResponse)=>
                      {
                            console.log(error+" Failure ");
                            if(error instanceof Error)
                            {
                                console.log("Client side error "+error);
                            }
                            else
                            {
                                console.log("Server side error "+error);
                            }
                      }
            );
        }
      
    //this method is initiated when Login button is hit on login form which toggles to login form ----------------------

      onLoginClick()
      {
         this.login=true;
      }


    //this method is triggered when when signUp button is hit which toggles SignUp form----------------------------
      onSignClick()
      {
          this.login=false;
      }

}
