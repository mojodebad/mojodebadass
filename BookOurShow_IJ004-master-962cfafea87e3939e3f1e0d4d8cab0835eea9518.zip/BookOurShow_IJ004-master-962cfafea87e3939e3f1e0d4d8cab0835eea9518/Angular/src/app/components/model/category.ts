//Model class for seat category-----------------------------------------------------------
export class Category{
    constructor(
        public categoryId?:any,
        public categoryName?:any
    ){

    }
}