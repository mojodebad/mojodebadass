//Model Class for Storing State Information
export class State{
    constructor(
        public stateId?:any,
        public stateName?:any
    ){

    }
}