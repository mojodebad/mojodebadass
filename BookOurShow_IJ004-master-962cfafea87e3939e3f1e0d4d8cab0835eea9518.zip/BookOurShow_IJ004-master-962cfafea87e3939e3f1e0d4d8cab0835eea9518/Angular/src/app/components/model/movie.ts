//Model Class for Movie Information -----------------------------------------------------
export class Movie{
    constructor(
        public movieId?:any,
        public movieName?:any,
        public movieReleaseDate?:any
    ){

    }
}