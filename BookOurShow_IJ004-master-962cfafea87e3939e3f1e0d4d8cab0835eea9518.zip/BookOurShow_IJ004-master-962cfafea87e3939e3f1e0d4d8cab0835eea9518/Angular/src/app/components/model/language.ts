// Model class for Fetching Language information------------------------------------------
export class Language{
    constructor(
        public languageId?:any,
        public languageName?:any
    ){

    }
}