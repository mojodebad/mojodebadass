//Model class for fetching city ------------------------------------------------------
export class City{
    constructor(
        public cityId?:any,
        public cityName?:any
    ){

    }
}