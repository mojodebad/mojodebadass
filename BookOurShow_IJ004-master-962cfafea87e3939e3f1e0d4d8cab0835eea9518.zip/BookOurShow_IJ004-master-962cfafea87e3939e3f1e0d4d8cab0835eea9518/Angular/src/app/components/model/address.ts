import { City } from './city';
import { State } from './state';
// Model class for fetching address and storing---------------------------------------  
export class Address{
    constructor(
    public city?:City,
    public state?:State){

    }
}