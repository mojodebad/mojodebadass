import { Language } from './language';
//Model class for Storing Venue Information 
export class Venue{
    constructor(public bookDate?:any,public language?:Language){
        
    }
}