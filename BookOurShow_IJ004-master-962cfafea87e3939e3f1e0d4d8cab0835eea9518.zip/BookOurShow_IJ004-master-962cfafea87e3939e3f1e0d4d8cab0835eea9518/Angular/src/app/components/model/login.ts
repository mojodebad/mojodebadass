//Model class for Login and registration --------------------------------------------------
export class Login {
    userId:any;
    email:string;
    password:string;
    userName:string;
    getUserId():any{
        return this.userId;
    }
    getUserName():string
    {
        return this.userName;
    }
    getEmail():string
    {
        return this.email;
    }
    getPassword():string
    {
        return this.password;
    }
    setUserName(userName:string){
        this.userName=userName;
    }
    setEmail(email:string){
        this.email=email;
    }
    setPassword(password:string){
        this.password=password;
    }
}
