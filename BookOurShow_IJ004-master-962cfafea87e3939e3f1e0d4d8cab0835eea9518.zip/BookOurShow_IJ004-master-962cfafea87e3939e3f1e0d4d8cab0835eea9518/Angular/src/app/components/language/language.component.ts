import { Component, OnInit } from '@angular/core';
import { BookOurShowService } from '../services/bookshow.service';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { Language } from '../model/language';
import { Venue } from '../model/venue';
import { DatePipe } from '@angular/common';
//import { Alert } from 'selenium-webdriver';
import { AppComponent } from '../../app.component';

@Component({
  selector: 'language',
  templateUrl: './language.component.html',
  styleUrls: ['./language.component.css']
})
export class LanguageComponent implements OnInit {

    private languageList:any;

  //Declaring the variables for fetching language according to selected city and movie------------------------------- 
    language:Language=new Language("","");
    venue:Venue=new Venue("",this.language);
    cityId:any;
    movieId:any;
    minDate:any;

    
    constructor(private app: AppComponent,private _service:BookOurShowService,private router:Router,private route:ActivatedRoute,private datePipe:DatePipe) { }
    

     // entering city Id an movieId from route parameters---------------------------------------
    //fetching the langauges in which the selected movie is being played in the selected city.

    ngOnInit() {
                
                 
                
                 this.cityId=this.route.snapshot.paramMap.get("cityId");
                 console.log("CITY ID---->"+this.cityId);
                 this.movieId=this.route.snapshot.paramMap.get("movieId");
                 console.log("MOVIE ID---->"+this.movieId);
                 this.minDate=Date.now();
      
                 this._service.fetchLanguage(this.cityId,this.movieId).subscribe(
                      (res)=>{
                                console.log(JSON.stringify(res)+" Success ");
                                this.languageList=res;
                      },
                      (error:HttpErrorResponse)=>{
                                 console.log(error+" Failure ");
                                 if(error instanceof Error){
                                    console.log("Client side error "+error);
                                 }
                                 else
                                 {
                                   console.log("Server side error "+error);
                                 }
                     }
                 );
    }

    //this function is called when PICK A VENUE button is pressed.
    //Here we are stornig the book date in local storage and navigating to venue page.
    
    onBook(venue:Venue){
                 localStorage.setItem("bookDate",venue.bookDate);
                 //alert("SELECTED DATE-------> "+venue.bookDate);
                 var curDate;
                 var todayDate=Date.now();
        
                 curDate = this.datePipe.transform(todayDate, 'yyyy-MM-dd');
                 //alert("CURRENT DATE----->"+curDate);

                 if(curDate<=venue.bookDate){
                            //alert("CORRECT DATE");
                            this.router.navigate(['/venue',this.cityId,this.movieId,venue.language.languageId]);
                 }
                 else{
                           alert("INCORRENT DATE.. SELECT CORRECT DATE");
                 }

    }


}
