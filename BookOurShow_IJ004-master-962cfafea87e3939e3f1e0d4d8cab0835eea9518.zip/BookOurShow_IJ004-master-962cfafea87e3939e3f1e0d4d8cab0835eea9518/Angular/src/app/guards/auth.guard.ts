import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

//implementation of route gaurd --------------------------------------------------------------

export class AuthGuard implements CanActivate {
  data:any;
  constructor(private router:Router){}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      this.data=localStorage.getItem("user");
      if(this.data!=null)
      {
        return true;
      }
      else
      {
        console.log(state.url);
        console.log(this.router.navigate(["login"],{queryParams:{returnUrl:state.url}}));
       alert("please login to go further");
        this.router.navigate(["login"],{queryParams:{returnUrl:state.url}});
        return false;
      }
  }
}
