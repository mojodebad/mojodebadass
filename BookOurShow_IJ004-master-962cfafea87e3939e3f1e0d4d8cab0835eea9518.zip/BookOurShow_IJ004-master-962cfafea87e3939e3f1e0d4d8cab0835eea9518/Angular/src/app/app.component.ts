import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'book-our-show';
  public loginFlag:boolean = false;
  
  // setLoginFlag(flag)
  // {
  //   this.loginFlag=flag;
  // }
  // getLoginFlag():boolean{
  //   return this.loginFlag;
  // }
  loginCheck():boolean
  {
    if(localStorage.getItem("user")==null)
    {
      this.loginFlag=false;
    }
    else{
      this.loginFlag=true;
    }
    return this.loginFlag;
  }
}
