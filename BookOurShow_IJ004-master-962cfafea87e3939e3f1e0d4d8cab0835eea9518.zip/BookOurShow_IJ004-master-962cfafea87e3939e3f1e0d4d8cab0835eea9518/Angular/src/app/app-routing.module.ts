import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LocationComponent } from './components/location/location.component';
import { MovieComponent } from './components/movie/movie.component';
import { LanguageComponent } from './components/language/language.component';
import { VenueComponent } from './components/venue/venue.component';
import { SeatsComponent } from './components/seats/seats.component';
import { BillComponent } from './components/bill/bill.component';
import { AuthGuard } from './guards/auth.guard';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { LogoutComponent } from './components/logout/logout.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [
  {path:"location",component:LocationComponent,canActivate:[AuthGuard]},
  {path:"movie/:cityId",component:MovieComponent,canActivate:[AuthGuard]},
  {path:"language/:cityId/:movieId",component:LanguageComponent,canActivate:[AuthGuard]},
  {path:"venue/:cityId/:movieId/:languageId",component:VenueComponent,canActivate:[AuthGuard]},
  {path:"seats/:venueScheduleId/:bookDate",component:SeatsComponent,canActivate:[AuthGuard]},
  {path:"bill/:bookingId",component:BillComponent,canActivate:[AuthGuard]},
  {path:"login", component: LoginComponent},
  {path:"logout", component: LogoutComponent,canActivate:[AuthGuard]},
  {path:"register", component: LoginComponent}
];
// ,{path:"home",component:HomeComponent}
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
