package com.stackroute.moviecruiserserver.service;

import static org.junit.Assert.*;




import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.when;
import com.stackroute.moviecruiserserver.domain.Movie;
import com.stackroute.moviecruiserserver.exception.MovieAlreadyExistException;
import com.stackroute.moviecruiserserver.exception.MovieNotFound;
import com.stackroute.moviecruiserserver.repository.MovieRepository;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

public class MovieServiceImplTest {

	@Mock
	private transient MovieRepository movierepo;
	
	private transient Movie movie;
	
	@InjectMocks
	private transient MovieServiceImpl movieServiceImpl;
	
	transient Optional<Movie> options;
	
	@Before
	public void setUpMock()
	{
		MockitoAnnotations.initMocks(this);
		movie=new Movie(1,12,"DB Super","Anime","Toei Animations","4-04-2019",88,1222,"Jason123");
		options=Optional.of(movie);
	}
	
	@Test
	public void testMockCreation() {
		assertNotNull("Jpa repository creation failed:use Inject mocks on movieserviceImpl",movierepo);
	}
	
	@Test
	public void testSaveMovieSucess() throws MovieAlreadyExistException
	{
		when(movierepo.save(movie)).thenReturn(movie);
		final boolean flag=movieServiceImpl.saveMovie(movie);
		assertTrue("saving movie failed,the call to movieDaoImpl is returning false,check this method",flag);
		verify(movierepo,times(1)).save(movie);
		//verify(movierepo,times(1)).findById(movie.getId());
	}
	
	@Test(expected=MovieAlreadyExistException.class)
	public void testSaveMovieFailure()throws MovieAlreadyExistException
	{
		when(movierepo.findById(1)).thenReturn(options);
		when(movierepo.save(movie)).thenReturn(movie);
		final boolean flag=movieServiceImpl.saveMovie(movie);
		assertFalse("Saving movie failed",flag);
		verify(movierepo,times(1)).findById(movie.getId());
	}
	@Test
	public void testUpdateMovie()throws MovieNotFound
	{   
		when(movierepo.findById(1)).thenReturn(options);
		when(movierepo.save(movie)).thenReturn(movie);
		movie.setComments("Akira Toriyama animations");
		final Movie movie2=movieServiceImpl.updateMovie(movie);
		assertEquals("Akira Toriyama animations", movie2.getComments());
		verify(movierepo,times(1)).save(movie);
		verify(movierepo,times(1)).findById(movie.getId());
	}
    @Test
    public void testDeleteMovieById() throws MovieNotFound 
    {
                    when(movierepo.findById(1)).thenReturn(options);
                    doNothing().when(movierepo).delete(movie);
                    final boolean flag = movieServiceImpl.deleteMovieById(1);
                    assertTrue("deleting movie failed", flag);
                    verify(movierepo,times(1)).delete(movie);
                    verify(movierepo,times(1)).findById(movie.getId());
    }


	@Test
	public void testGetMovieById() throws MovieNotFound
	{
    		when(movierepo.findById(1)).thenReturn(options);
    		final Movie movie1=movieServiceImpl.getMovieById(1);
    		assertEquals("fetching movie by Id failed ",movie1,movie);
    		verify(movierepo,times(1)).findById(movie.getId());
	}

	@Test
	public void testGetMyMovies() throws MovieNotFound
	{
		final List<Movie> movieList=new ArrayList<Movie>();
		movieList.add(movie);
		when(movierepo.findByUserId("Jason123")).thenReturn(movieList);
		final List<Movie> movies1=movieServiceImpl.getMyMovies("Jason123");
		assertEquals(movieList,movies1);
		verify(movierepo,times(1)).findByUserId("Jason123");
	}
}
