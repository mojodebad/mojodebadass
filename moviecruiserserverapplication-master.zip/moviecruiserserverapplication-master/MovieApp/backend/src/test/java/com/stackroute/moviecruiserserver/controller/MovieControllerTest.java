package com.stackroute.moviecruiserserver.controller;


import static org.junit.Assert.fail;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;   // ...or...
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.moviecruiserserver.domain.Movie;
import com.stackroute.moviecruiserserver.service.MovieService;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;

@RunWith(SpringRunner.class)
@WebMvcTest(MovieController.class)
public class MovieControllerTest {
	@Autowired
	private transient MockMvc mvc;
    
	@MockBean
    private transient MovieService service;
    
	private transient Movie movie=null;
	static List<Movie> movieList=new ArrayList<Movie>();
	static List<Movie> movies=new ArrayList<Movie>();
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	   
	    
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	
		  movie=new Movie(2,34,"Ninja","Action","mvn production","02-12-2013",29,123,"KhalDrogo");
		    movies.add(movie);
		    movieList.add(movie);
			 movie=new Movie(3,234,"Undisputed3","Action","Fox century production","04-11-2013",(float) 55.00,124,"KhalDrogo");
		    movies.add(movie);
		    movieList.add(movie);
		    movies.add(new Movie(6,35,"Undisputed4","Action","Fox century production","04-11-2018",(float) 55.7,120,"Boyka"));
		   	} 


	@After
	public void tearDown() throws Exception {
	}

	/*@Test
	public void test() {
		fail("Not yet implemented");
	}*/
	@Test 
   public void testSaveNewMovie() throws Exception
   {
		String token="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJCYXRtYW4iLCJpYXQiOjE1NTM2ODIyOTJ9.T1NwMVHu1lk01JQX3P3rZRnxwIxSU8pOmolSEKd0km8";
	   when(service.saveMovie(movie)).thenReturn(true);
	   mvc.perform(post("/api/v1/movieservice").header("authorization","Bearer "+token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie))).andExpect(status().isCreated()).andDo(print());
	   verify(service,times(1)).saveMovie(Mockito.any(Movie.class));
	   verifyNoMoreInteractions(service);
   }
   
   @Test
   public void testMovieUpdateSucess() throws Exception
   {
	   movie.setComments("no more codes please!");
	   when(service.updateMovie(movie)).thenReturn(movies.get(0));
	   mvc.perform(put("/api/v1/movieservice/movie/{id}",2).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie))).andExpect(status().isOk());
	   verify(service,times(1)).updateMovie(Mockito.any(Movie.class));
	   verifyNoMoreInteractions(service);
   }
   
   @Test
   public void testDeleteMovieById() throws Exception
   {
	   when(service.deleteMovieById(3)).thenReturn(true);
	   mvc.perform(delete("/api/v1/movieservice/movie/{id}",3)).andExpect(status().isOk());
	   verify(service,times(1)).deleteMovieById(3);
	   verifyNoMoreInteractions(service); 
   }
   @Test
   public void testFechMovieById()throws Exception
   {
	   when(service.getMovieById(2)).thenReturn(movies.get(0));
	   mvc.perform(get("/api/v1/movieservice/movie/{id}",2)).andExpect(status().isOk());
	   verify(service,times(1)).getMovieById(2);
	   verifyNoMoreInteractions(service);    
   }
   
   @Test
   public void testFetchMyMovies() throws Exception
   {
	   String token="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJCYXRtYW4iLCJpYXQiOjE1NTM2ODIyOTJ9.T1NwMVHu1lk01JQX3P3rZRnxwIxSU8pOmolSEKd0km8";
	   when(service.getMyMovies("KhalDrogo")).thenReturn(movieList);
	   mvc.perform(get("/api/v1/movieservice/movie").header("authorization","Bearer "+token).contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print());
	   verify(service,times(1)).getMyMovies("Jason123");
	   verifyNoMoreInteractions(service);  
   }
   
   
   private static String jsonToString(final Object obj) throws JsonProcessingException
   {
		
		String result;
		try{
			final ObjectMapper mapper=new ObjectMapper();
			final String jsonContent=mapper.writeValueAsString(obj);
			result=jsonContent;
		}
		catch(JsonProcessingException e){
			result="Json processing error";
		}
		return result;
	} 
}
