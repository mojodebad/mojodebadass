package com.stackroute.moviecruiserserver.repository;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.stackroute.moviecruiserserver.domain.Movie;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Transactional
public class MovieRepositoryTest {
	@Autowired
	private transient MovieRepository repo;
	public void setRepo(final MovieRepository repo)
	{
		this.repo=repo;
	}

	@Test
	public void testSaveMovie()throws Exception {
		repo.save(new Movie(2,67,"Ninja","Action","mvn production","02-12-2013",29,123,"Jason123"));
		final Movie movie=repo.getOne(2);
		assertThat(movie.getId()).isEqualTo(2);
	}
	@Test
	public void testUpdateMovie() throws Exception
	{
		repo.save(new Movie(2,67,"Ninja","Action","mvn production","02-12-2013",29,123,"Jason123"));
		final Movie movie=repo.getOne(2);
		assertThat(movie.getName()).isEqualTo("Ninja");
		movie.setComments("Warner Bros prodction");
		repo.save(movie);
		final Movie tempMovie=repo.getOne(2);
		assertThat(movie.getComments()).isEqualTo(tempMovie.getComments());
	}
	@Test
	public void testDeleteMovie() throws Exception
	{
		repo.save(new Movie(2,67,"Ninja","Action","mvn production","02-12-2013",29,123,"Jason123"));
		final Movie movie=repo.getOne(2);
		assertThat(movie.getName()).isEqualTo("Ninja");
		repo.delete(movie);
		assertEquals(Optional.empty(),repo.findById(2));
	}
	@Test
	public void testGetAllMovie() throws Exception
	{
		repo.save(new Movie(2,67,"Ninja","Action","mvn production","02-12-2013",29,123,"Jason123"));
		repo.save(new Movie(3,56,"Undisputed3","Action","Fox century production","04-11-2013",55,124,"MutterChord"));
		final List<Movie> movielist=repo.findAll();
		assertEquals(movielist.get(1).getName(),"Ninja");
	}
	
	@Test 
	public void TestGetMovie() throws Exception
	{
		repo.save(new Movie(2,67,"Ninja","Action","mvn production","02-12-2013",29,123,"MutterChord"));
		final Movie movie=repo.getOne(2);
		assertThat(movie.getName()).isEqualTo("Ninja");
	}
    

	@Test 
	public void TestGetMyMovies() throws Exception
	{
		repo.save(new Movie(2,67,"Ninja","Action","mvn production","02-12-2013",29,123,"Jason123"));
		repo.save(new Movie(3,56,"Ninja3","Action","mvn production & WB","04-11-2015",(float) 49.2,123,"Jason123"));
		final List<Movie> movies=repo.findByUserId("Jason123");
		assertThat(movies.get(0).getName()).isEqualTo("Ninja");
		assertThat(movies.get(1).getName()).isEqualTo("Ninja3");
	}

}
