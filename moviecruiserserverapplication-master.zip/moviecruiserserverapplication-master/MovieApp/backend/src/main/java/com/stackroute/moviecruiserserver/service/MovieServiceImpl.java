package com.stackroute.moviecruiserserver.service;

import java.util.ArrayList;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.moviecruiserserver.domain.Movie;
import com.stackroute.moviecruiserserver.exception.MovieAlreadyExistException;
import com.stackroute.moviecruiserserver.exception.MovieNotFound;
import com.stackroute.moviecruiserserver.repository.MovieRepository;


@Service
public class MovieServiceImpl implements MovieService {

	MovieRepository movierepository;

	@Autowired
	public MovieServiceImpl(MovieRepository movierepository) {
		
		this.movierepository = movierepository;
	}



	@Override
	public boolean saveMovie(final Movie movie) throws MovieAlreadyExistException 
	{
		// TODO Auto-generated method stub
		/*if (movierepository.existsById(movie.getId())) {
			throw new MovieAlreadyExistException("movie already exist");
		} else {
			movierepository.save(movie);
			return true;
		}*/
		System.out.println(movie);
		final Optional<Movie> object=movierepository.findById(movie.getId());
		if(object.isPresent())
		{
			System.out.println("error");
			throw new MovieAlreadyExistException("movie already exist");
		}
		movierepository.save(movie);
		return true;
	}

	@Override
	public Movie updateMovie(Movie updatemovie) throws MovieNotFound {
		// TODO Auto-generated method stub
		final Movie movie = movierepository.findById(updatemovie.getId()).orElse(null);
		if (movie == null) {
			throw new MovieNotFound("Movie not found,cannot update");
		}
		movie.setComments(updatemovie.getComments());
		movierepository.save(movie);
		return movie;
	}

	@Override
	public Movie getMovieById(int id) throws MovieNotFound {
		// TODO Auto-generated method stub
		Optional<Movie> movie = movierepository.findById(id);
		if (movie.isPresent()) {
			return movie.get();
		} else {
			throw new MovieNotFound("movie dosent exist");
		}
	}

	@Override
	public boolean deleteMovieById(final int id) throws MovieNotFound {
		// TODO Auto-generated method stub
		final Movie movie =  movierepository.findById(id).orElse(null);
		if(movie==null)
		{
			throw new MovieNotFound("could not delete the movie,movie dosent exist");
		} 
		movierepository.delete(movie);
		return(true);
	}

	@Override
	public List<Movie> getMyMovies(String userId) {
		// TODO Auto-generated method stub
		return movierepository.findByUserId(userId);
				
	}

}
