package com.stackroute.moviecruiserserver.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movie")
public class Movie {
	public Movie() {
		super();
	}

	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	@Column(name ="id")
	private int id=0;
	
	@Column(name ="movie_id")
    private int movieId;
	
	
	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	@Column(name= "name")
	private String name;
	
	@Column(name= "comments")
	private String comments;
	
	@Column(name="poster_path")
	private String posterpath;
	
	@Column(name="release_date")
	private String releasedate;
	
	@Column(name="vote_average")
	private float voteAverage;
	
	@Column(name="vote_count")
    private int voteCount;
	
	@Column(name="user_id")
	private String userId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getPosterpath() {
		return posterpath;
	}

	public void setPosterpath(String posterpath) {
		this.posterpath = posterpath;
	}

	public String getReleasedate() {
		return releasedate;
	}

	public void setReleasedate(String releasedate) {
		this.releasedate = releasedate;
	}

	public float getVoteAverage() {
		return voteAverage;
	}

	public void setVoteAverage(float voteAverage) {
		this.voteAverage = voteAverage;
	}

	public int getVoteCount() {
		return voteCount;
	}

	public void setVoteCount(int voteCount) {
		this.voteCount = voteCount;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Movie [id=" + id + ", movieId=" + movieId + ", name=" + name + ", comments=" + comments
				+ ", posterpath=" + posterpath + ", releasedate=" + releasedate + ", voteAverage=" + voteAverage
				+ ", voteCount=" + voteCount + ", userId=" + userId + "]";
	}

	public Movie(int id, int movieId, String name, String comments, String posterpath, String releasedate,
			float voteAverage, int voteCount, String userId) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.name = name;
		this.comments = comments;
		this.posterpath = posterpath;
		this.releasedate = releasedate;
		this.voteAverage = voteAverage;
		this.voteCount = voteCount;
		this.userId = userId;
	}

	
	


	

}
