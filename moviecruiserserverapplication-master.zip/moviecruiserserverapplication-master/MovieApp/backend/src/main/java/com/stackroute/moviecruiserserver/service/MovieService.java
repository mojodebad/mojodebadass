package com.stackroute.moviecruiserserver.service;

import java.util.List;

import com.stackroute.moviecruiserserver.domain.Movie;
import com.stackroute.moviecruiserserver.exception.MovieAlreadyExistException;
import com.stackroute.moviecruiserserver.exception.MovieNotFound;

public interface MovieService {

	

	public boolean saveMovie(final Movie movies) throws MovieAlreadyExistException ;

	public Movie updateMovie(final Movie updatemovie) throws MovieNotFound;

	public Movie getMovieById(final int id) throws MovieNotFound;
	
	public boolean deleteMovieById(final int id) throws MovieNotFound;
    public List<Movie>  getMyMovies(final String userId);
    
}
