package com.stackroute.moviecruiserserver.exception;

public class MovieNotFound extends Exception {

	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
  


	@Override
	public String toString() {
		return "MovieNotFound [message=" + message + "]";
	}

	public MovieNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
