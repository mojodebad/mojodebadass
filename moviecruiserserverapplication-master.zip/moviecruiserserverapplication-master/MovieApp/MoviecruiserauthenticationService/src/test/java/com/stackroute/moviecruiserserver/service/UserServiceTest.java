package com.stackroute.moviecruiserserver.service;

import static org.junit.Assert.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.Optional;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.moviecruiserserver.domain.User;
import com.stackroute.moviecruiserserver.exceptions.UserAlreadyExistsException;
import com.stackroute.moviecruiserserver.exceptions.UserNotFoundException;
import com.stackroute.moviecruiserserver.repository.UserRepository;

public class UserServiceTest {
	
	@Mock
	private UserRepository userRepo;
	private User user;
	@InjectMocks
	private UserServiceImpl userserviceimpl;
	
	Optional<User> options;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		user=new User("KhalDrogo","Jason","Mamoa","123456",new Date());
		options=Optional.of(user);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testSavedUserSucess() throws UserAlreadyExistsException, UserNotFoundException {
		
		when(userRepo.save(user)).thenReturn(user);
		boolean flag=userserviceimpl.savedUser(user);
		assertEquals("Cannot Register user",true,flag);
		verify(userRepo,times(1)).save(user);
		
	}
	
	@Test(expected=UserAlreadyExistsException.class)
    public void testSavedUserFailure() throws UserAlreadyExistsException, UserNotFoundException {
		
		when(userRepo.findById(user.getUserId())).thenReturn(options);
		when(userRepo.save(user)).thenReturn(user);
		boolean flag=userserviceimpl.savedUser(user);
		
		
	}

	@Test
	public void testFindByUserIdAndPasswordSucess() throws UserNotFoundException {
		when(userRepo.findByUserIdAndPassword(user.getUserId(),user.getPassword())).thenReturn(user);
		User userResult=userserviceimpl.findByUserIdAndPassword(user.getUserId(),user.getPassword());
		assertNotNull(userResult);
		assertEquals("KhalDrogo",userResult.getUserId());
		verify(userRepo,times(1)).findByUserIdAndPassword(user.getUserId(),user.getPassword());
	}

	@Test(expected=UserNotFoundException.class)
	public void testFindByUserIdAndPasswordFailure() throws UserNotFoundException
	{
	    when(userRepo.findById("KhalDrogo")).thenReturn(null);
	    userserviceimpl.findByUserIdAndPassword(user.getUserId(),user.getPassword());
	}
}
