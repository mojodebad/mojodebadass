package com.stackroute.moviecruiserserver.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.Date;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.moviecruiserserver.domain.User;
import com.stackroute.moviecruiserserver.service.SecurityTokenGenerator;
import com.stackroute.moviecruiserserver.service.UserService;
@RunWith(SpringRunner.class)
@WebMvcTest(UserController.class)
public class UserControllerTest {

	@Autowired
	private MockMvc mockmvc;
	@MockBean
	private UserService userservice; 
	@MockBean
	private SecurityTokenGenerator securityTokenGenerator;
	private User user;
	@InjectMocks
	UserController userController;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		user=new User("KhalDrogo","Jason","Mamoa","123456",new Date());
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void TestRegisterUser() throws JsonProcessingException, Exception {
		when(userservice.savedUser(user)).thenReturn(true);
		mockmvc.perform(post("/user/register").contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON).content(jsonToString(user))).andExpect(status().isCreated()).andDo(print());
		verify(userservice,times(1)).savedUser(Mockito.any(User.class));
	    verifyNoMoreInteractions(userservice);
		
	}
	@Test
	public void TestLoginUser() throws JsonProcessingException, Exception{
		String userId="KhalDrogo";
		String password="123456";
		when(userservice.savedUser(user)).thenReturn(true);
		when(userservice.findByUserIdAndPassword(userId,password)).thenReturn(user);
		mockmvc.perform(post("/user/login").contentType(MediaType.APPLICATION_JSON).content(jsonToString(user))).andExpect(status().isOk());
	}
	
	private static String jsonToString(final Object obj) throws JsonProcessingException{
		
		String result;
		try
		{
			 final ObjectMapper mapper=new ObjectMapper();
			 final String jsonContent=mapper.writeValueAsString(obj);
			 result= jsonContent;
	    }
		catch(JsonProcessingException e){
		     result="Json processing eror";	
		}
	    return result;
    }

	
}	