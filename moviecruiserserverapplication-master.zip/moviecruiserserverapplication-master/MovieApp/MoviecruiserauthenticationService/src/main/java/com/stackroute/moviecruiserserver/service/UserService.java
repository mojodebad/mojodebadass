package com.stackroute.moviecruiserserver.service;

import com.stackroute.moviecruiserserver.domain.User;
import com.stackroute.moviecruiserserver.exceptions.UserAlreadyExistsException;
import com.stackroute.moviecruiserserver.exceptions.UserNotFoundException;

public interface UserService {
 boolean savedUser(User user) throws UserAlreadyExistsException, UserNotFoundException; 
 public User findByUserIdAndPassword(String UserId,String Password) throws UserNotFoundException;
}
