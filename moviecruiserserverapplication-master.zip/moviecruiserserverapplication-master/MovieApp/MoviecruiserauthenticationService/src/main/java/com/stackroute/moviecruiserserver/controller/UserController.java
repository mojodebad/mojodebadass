package com.stackroute.moviecruiserserver.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.stackroute.moviecruiserserver.domain.User;
import com.stackroute.moviecruiserserver.service.SecurityTokenGenerator;
import com.stackroute.moviecruiserserver.service.UserService;
@RestController
@EnableWebMvc
@RequestMapping("/user")
public class UserController {

 @Autowired
  private UserService userservice;
 @Autowired
 private SecurityTokenGenerator tokenGenerator;
 
 @PostMapping("/register")
 public ResponseEntity<?> registeredUser(@RequestBody User user)
 {
	 try
	 {
		 userservice.savedUser(user);
		 return new ResponseEntity<String>("user sucessfully registered",HttpStatus.CREATED);
	 }
	 catch(Exception e)
	 {
		 return new ResponseEntity<String>("user not registered->{"+e.getMessage() + "}",HttpStatus.CONFLICT);
	 }
 }
 @PostMapping("/login")
 public ResponseEntity<?> LoginUser(@RequestBody User loginDetails)
 {
	 try
	 {
		 String userId=loginDetails.getUserId();
		 String password=loginDetails.getPassword();
		 if(userId== null ||password ==null)
		 {
			 throw new Exception("username or password cannot be empty");
		 }
		  User user=userservice.findByUserIdAndPassword(userId, password);
		 if(user== null)
		 {
			 throw new Exception("user with this user id and password does not exist");
			 
		 }
		  String pwd=user.getPassword();
		  if(!password.equals(pwd))
		  {
			  throw new Exception("Wrong password");
		  }
		  Map<String,String> map=tokenGenerator.generateToken(user);
		  System.out.println("MAP:"+map);
		  return new ResponseEntity<Map<String,String>>(map,HttpStatus.OK);
	 }
	 catch(Exception e)
	 {
		 return new  ResponseEntity<String>("message->{"+e.getMessage()+"}",HttpStatus.UNAUTHORIZED);	
	 }
 }
 
}
