package com.stackroute.moviecruiserserver.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.stackroute.moviecruiserserver.domain.User;

@Repository
public interface UserRepository extends JpaRepository<User,String> {

	/*@Query("select * from User where User u where userId=(?) and password=(?)")
	User validate(String UserId,String Password)*/
	User findByUserIdAndPassword(String userId,String password);
	
	
}
