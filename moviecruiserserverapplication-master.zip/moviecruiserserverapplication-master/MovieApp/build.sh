#/bin/bash

cd MovieCruiserAuthenticationService
Source ./env-variable.sh
mvn clean package
docker build -t user-app .
cd ..
cd backend
Source ./env-variable.sh
mvn clean package
docker build -t movie-app .
cd ..
