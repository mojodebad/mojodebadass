import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { MatCardModule } from '@angular/material/card';
import { ContainerComponent } from './components/container/container.component';
import { MovieRouterModule } from './movie.router';
import { WatchlistComponent } from './components/watchlist/watchlist.component';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MovieDialogComponent } from './components/movie-dialog/movie-dialog.component';
import { SearchComponent } from './components/search/search.component';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { IntercepterService } from './service/intercepter.service';
import { MovieService } from './service/movie.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
@NgModule({
  declarations: [ThumbnailComponent, ContainerComponent, WatchlistComponent, TmdbContainerComponent, MovieDialogComponent, SearchComponent],
  imports: [
    MatInputModule,
    MatSnackBarModule,
    MatCardModule,
    CommonModule,
    MovieRouterModule,
    FormsModule,
    MatFormFieldModule,
    MatButtonModule
  ],
  exports: [
    ThumbnailComponent,
    ContainerComponent,
    MovieRouterModule,
    TmdbContainerComponent,
    WatchlistComponent,
    MovieDialogComponent,
    MatFormFieldModule,
    MatInputModule
  ],
  entryComponents: [
    MovieDialogComponent
  ],
  providers: [
    MovieService, {
      provide: HTTP_INTERCEPTORS,
      useClass: IntercepterService,
      multi: true
    }, IntercepterService
  ]
})
export class MovieModule { }
