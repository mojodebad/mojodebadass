import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { Movie } from '../movie';
import { MovieBackend } from '../../MovieBackend';
import { map, retry } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  tmdbEndpoint: string;
  imagePrefix: string;
  apiKey: string;
  springBootEndpoint: string;
  watchlistEndpoint: string;
  search: string;

  constructor(private http: HttpClient) {
    this.imagePrefix = 'https://image.tmdb.org/t/p/w500';
    this.tmdbEndpoint = "https://api.themoviedb.org/3/movie";
    this.apiKey = "api_key=e5dc618a85d798a96af2b5f9c3fe963a";
    this.watchlistEndpoint = "http://localhost:3000/Watchlist";
    this.springBootEndpoint = "http://localhost:8080/api/v1/movieservice";
    this.search = 'https://api.themoviedb.org/3/search/movie?';
  }

  getMovieBackendFromMovie(movie: Movie) {
    let movieBackend: MovieBackend = {
      id:movie.pid,
      movieId: movie.id,
      name: movie.title,
      comments: movie.comments,
      posterpath: movie.poster_path,
      releasedate: movie.release_date,
      voteAverage: movie.vote_average,
      voteCount: movie.vote_count
    }
    return movieBackend;
  }
  getMovieFromMovieBackend(movieBackend: MovieBackend) {

    let movie: Movie = {
      pid:movieBackend.id,
      id: movieBackend.movieId,
      title: movieBackend.name,
      release_date: movieBackend.releasedate,
      poster_path: movieBackend.posterpath,
      comments: movieBackend.comments,
      vote_average: movieBackend.voteAverage,
      vote_count: movieBackend.voteCount,
      overview: ''
    }
    return movie;
  }
  getMovies(type: string, page: number = 1): Observable<Array<Movie>> {
    const Endpoint = `${this.tmdbEndpoint}/${type}?${this.apiKey}&page=${page}`;
    return this.http.get(Endpoint).pipe(map(this.pickMovieResults), map(this.transfromPosterPath.bind(this)));
  }

  transfromPosterPath(movies): Array<Movie> {
    return movies.map(movie => {
      movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
      return movie;
    });
  }

  pickMovieResults(response) {
    return response['results'];
  }
  
  getWatchListedMovie(): Observable<Array<MovieBackend>> {
    return this.http.get<Array<MovieBackend>>(this.springBootEndpoint+"/movies");  
  }
  saveWatchlistMovies(movie: Movie) {
    return this.http.post(this.springBootEndpoint+"/movie", this.getMovieBackendFromMovie(movie));
  }
  deleteFromMyWatchList(movie: Movie) {
    const url=this.springBootEndpoint+"/movie";
    const url1 = `${url}/${movie.id}`;
    console.log(movie);
    return this.http.delete(url1, { responseType: 'text' });
  }
  updateComments(movie: Movie) {
    const url=this.springBootEndpoint+"/movie";
    const url1= `${url}/${movie.id}`;
    return this.http.put(url1, this.getMovieBackendFromMovie(movie));
  }

  searchMovies(searchKey: string): Observable<Array<Movie>> {
    if (searchKey.length > 0) {
      const url = `${this.search}${this.apiKey}&language=en-US&page=1&include_adult=false&query=${searchKey}`;
      return this.http.get(url).pipe(retry(3),map(this.pickMovieResults),map(this.transfromPosterPath.bind(this)));
    }
    return null;
  }

}