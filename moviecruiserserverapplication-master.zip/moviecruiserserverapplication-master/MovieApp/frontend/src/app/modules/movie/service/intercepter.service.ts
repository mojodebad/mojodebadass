import { Injectable } from '@angular/core';
import {AuthenticationService} from '../../authentication/authentication.service'
import{
  HttpRequest,
  HttpEvent,
  HttpInterceptor,
  HttpHandler,

} from "@angular/common/http";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IntercepterService implements HttpInterceptor {

  constructor(private authservice:AuthenticationService) {
     
   }
   intercept(request:HttpRequest<any>,next:HttpHandler):  Observable<HttpEvent<any>>
   {
     const autherizationheader:string="Bearer "+this.authservice.getToken();
     console.log("In Intercept");
     request=request.clone({
       setHeaders:{
         authorization: autherizationheader
       }
     });
     return next.handle(request);
   }
}
