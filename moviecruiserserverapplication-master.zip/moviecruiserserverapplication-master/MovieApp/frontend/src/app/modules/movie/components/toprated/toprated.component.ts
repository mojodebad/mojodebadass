import { Component, OnInit } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../../service/movie.service'
@Component({
  selector: 'movie-toprated',
  templateUrl: './toprated.component.html',
  styleUrls: ['./toprated.component.css']
})
export class TopratedComponent implements OnInit {

  movies:Array<Movie>;
  constructor(private movieservice:MovieService) {
    this.movies=[];
   }
  ngOnInit() {
    this.movieservice.getMovies('top_rated',1).subscribe((movies) =>
    {
     this.movies.push(...movies);
    });
  }

}
