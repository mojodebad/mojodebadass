import { Component, OnInit } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../../service/movie.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'movie-tmdb-container',
  templateUrl: './tmdb-container.component.html',
  styleUrls: ['./tmdb-container.component.css']
})
export class TmdbContainerComponent implements OnInit {

  constructor(private movieservice:MovieService,private route:ActivatedRoute) {
    this.movies=[];
    this.route.data.subscribe((datam)=>{
      this.movieType=datam.movieType;
    });
   }

  movies:Array<Movie>;
  movieType:string;
 ngOnInit() 
  {
    this.movieservice.getMovies(this.movieType,1).subscribe((movies) =>
    {
     this.movies.push(...movies);
    });
  }


}
