import { Component, OnInit } from '@angular/core';
import {Movie} from '../../movie';
import {MovieService} from '../../service/movie.service';
import { MovieBackend } from 'src/app/modules/MovieBackend';
@Component({
  selector: 'movie-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchlistComponent implements OnInit {
  
  useWatchlistApi=true;
  movies:Array<Movie>=[];
  moviesFromBackend:Array<MovieBackend>=[];
  constructor(private movieservice:MovieService) {
  
   }

  ngOnInit() {
    this.movieservice.getWatchListedMovie().subscribe(movies=>{
      this.moviesFromBackend=movies;
      for(var i=0;i<this.moviesFromBackend.length;i++){
        this.movies[i] = this.movieservice.getMovieFromMovieBackend(this.moviesFromBackend[i]);
      }
    });
  }
}
