import { Component, OnInit } from '@angular/core';
import { Movie } from '../../movie';
import { MovieBackend } from 'src/app/modules/MovieBackend';
import { MovieService } from '../../service/movie.service';

@Component({
  selector: 'movie-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  movies:Array<Movie> = [];
  moviesBackend:Array<MovieBackend> = [];
  useWatchlistApi=false;
  constructor(private movieservice:MovieService) { }

  ngOnInit() {
  }

  onEnter(SearchKey)
  {
    console.log('search key',SearchKey);
    this.movieservice.searchMovies(SearchKey).subscribe(movies=>{
      this.movies=movies;
    });
  }
}
