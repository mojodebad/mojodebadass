export interface Movie
{
    pid:number;
    id:number;
    title:string;
    poster_path:string;
    overview:string;
    release_date:string;
    comments:string;
    vote_average:number;
    vote_count:number;
}