import { Component, OnInit, Input } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../service/movie.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'movie-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  @Input()
  movies: Array<Movie>;
  @Input()
  useWatchlistApi: boolean;
  constructor(private movieservice: MovieService, private snackbar: MatSnackBar) {
  }

  ngOnInit() { }

  addToWatchlist(movie) {
    console.log();
    this.movieservice.saveWatchlistMovies(movie).subscribe(() => {
      this.snackbar.open(" movie added to watchlist", '', {
        duration: 1000
      });
    });
  }
  deleteMovieFromWatchlist(movie) {

    let message = `${movie.title} deleted from your Watchlist `;
    for (var i = 0; i < this.movies.length; i++) {
      if (this.movies[i].title === movie.title) {
        this.movies.splice(i, 1);
      }
    }
    this.movieservice.deleteFromMyWatchList(movie).subscribe((movie) => {
      this.snackbar.open(message, '', {
        duration: 1000
      });
    });


    
  }
}
