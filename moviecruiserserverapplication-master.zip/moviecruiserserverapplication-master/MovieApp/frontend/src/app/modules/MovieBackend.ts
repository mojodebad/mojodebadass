export interface MovieBackend
{
    id:number;
    movieId:number;
    name:string;
    comments:string;
    posterpath:string;
    releasedate:string;
    voteAverage:number;
    voteCount:number;
    
}