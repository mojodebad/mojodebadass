import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import {FormsModule} from '@angular/forms';
import {MatButtonModule, MatFormFieldModule} from '@angular/material';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material';

import {RegisterComponent} from './register/register.component';
import {AuthenticationService} from './authentication.service';
import {MatCardModule} from '@angular/material/card';
import { AuthenticationRoutingModule } from './authentication-router.module';

@NgModule(
  {
  declarations: [LoginComponent,RegisterComponent],
  imports: [
    FormsModule,
    CommonModule,
    AuthenticationRoutingModule,
    MatSnackBarModule,
    MatIconModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  providers:
  [
    AuthenticationService
  ],
  exports:[RegisterComponent,LoginComponent]
})

 export class AuthenticationModule { }
 