import { Component, OnInit } from '@angular/core';
import { User } from '../User';
import { AuthenticationService } from '../authentication.service';
import { Router } from '@angular/router';
@Component({
  selector: 'movie-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  newUser:User;

  constructor(private authservice:AuthenticationService,private router:Router) { 
    this.newUser=new User();
  }

  ngOnInit() {
  }
 loginUser()
 {
   console.log("register user",this.newUser.userId,this.newUser.password)
   this.authservice.loginUser(this.newUser).subscribe(data=>{
     console.log("Logged in!!!");
     if(data["token"])
     {
       this.authservice.setToken(data["token"]);
       console.log("token",data["token"]);
       this.router.navigate(['/movies/popular']);      
      }
   })
  }
}
