import { Component, OnInit } from '@angular/core';
import { User} from "../User";
import { Router } from '@angular/router';
import {AuthenticationService} from '../authentication.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'movie-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

  newUser: User;

  constructor(private authservice:AuthenticationService,private router:Router, private snackbar: MatSnackBar) {
    this.newUser=new User();
   }

  ngOnInit() {
  }

  registerUser() {
    console.log("Register User",this.newUser.userId,this.newUser.firstName);
    this.authservice.registerUser(this.newUser).subscribe((data)=>{
      console.log(this.newUser);
      this.snackbar.open("Successfully Registered", "", {
        duration: 3000
      });
      this.router.navigate(['/login']);
    });

  }

}
