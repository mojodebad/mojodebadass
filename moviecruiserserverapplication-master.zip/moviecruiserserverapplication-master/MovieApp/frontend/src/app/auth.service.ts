import { Injectable } from '@angular/core';
import {AuthenticationService} from './modules/authentication/authentication.service'
import {CanActivate} from '@angular/router/src/interfaces';
import {Router} from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate{
  constructor(private route:Router,private authservice:AuthenticationService) {

  }
canActivate()
{
  if(!this.authservice.isTokenExpired())
  {
    return true;
  }
  this.route.navigate(['/login']);
  return false;
}  

  
}
