import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MovieModule } from './modules/movie/movie.module';
const routes: Routes = [
  // {
  //   path: '',
  //   redirectTo: '/movies',
  //   pathMatch: 'full',
  // },
  {
    path:'',
    redirectTo:'/login',
    pathMatch:'full'
  }
];

@NgModule({
  imports: [
    MovieModule,
    RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
